#!/usr/bin/env bash
set -e
mkdir -p app/src/main/java/com/vt100/ime app/src/main/res/xml app/src/main/res/values .github/workflows

cat > settings.gradle <<'EOF'
pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "VT100-IME"
include(":app")
EOF

cat > build.gradle <<'EOF'
plugins { id 'com.android.application' version '8.6.1' apply false }
EOF

cat > gradle.properties <<'EOF'
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
EOF

cat > app/build.gradle <<'EOF'
plugins { id 'com.android.application' }
android {
    namespace 'com.vt100.ime'
    compileSdk 35
    defaultConfig {
        applicationId 'com.vt100.ime'
        minSdk 26
        targetSdk 35
        versionCode 2
        versionName '0.2.0'
    }
    java { toolchain { languageVersion = JavaLanguageVersion.of(17) } }
}
EOF

cat > app/src/main/res/values/strings.xml <<'EOF'
<resources>
<string name="app_name">VT-100 PC Touch Keyboard</string>
<string name="keyboard_name">VT-100 PC Touch</string>
<string name="accessibility_name">VT-100 Touchpad</string>
</resources>
EOF

cat > app/src/main/res/values/styles.xml <<'EOF'
<resources>
<style name="AppTheme" parent="android:style/Theme.Material.NoActionBar">
<item name="android:fontFamily">sans</item>
<item name="android:colorAccent">#7aa2f7</item>
<item name="android:navigationBarColor">#16161e</item>
<item name="android:statusBarColor">#16161e</item>
</style>
</resources>
EOF

cat > app/src/main/res/xml/method.xml <<'EOF'
<?xml version="1.0" encoding="utf-8"?>
<input-method xmlns:android="http://schemas.android.com/apk/res/android">
<subtype android:label="@string/keyboard_name" android:imeSubtypeLocale="en_US" android:imeSubtypeMode="keyboard"/>
</input-method>
EOF

cat > app/src/main/res/xml/accessibility_service_config.xml <<'EOF'
<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
android:description="@string/accessibility_name"
android:accessibilityEventTypes="typeAllMask"
android:accessibilityFeedbackType="feedbackGeneric"
android:notificationTimeout="100"
android:canRetrieveWindowContent="false"
android:canPerformGestures="true"
android:accessibilityFlags="flagDefault"/>
EOF

cat > app/src/main/AndroidManifest.xml <<'EOF'
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
<application android:allowBackup="true" android:label="@string/app_name" android:supportsRtl="true" android:theme="@style/AppTheme">
<activity android:name=".SettingsActivity" android:exported="true">
<intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter>
</activity>
<service android:name=".VT100ImeService" android:exported="true" android:label="@string/keyboard_name" android:permission="android.permission.BIND_INPUT_METHOD">
<intent-filter><action android:name="android.view.InputMethod"/></intent-filter>
<meta-data android:name="android.view.im" android:resource="@xml/method"/>
</service>
<service android:name=".VT100AccessibilityService" android:exported="false" android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
<intent-filter><action android:name="android.accessibilityservice.AccessibilityService"/></intent-filter>
<meta-data android:name="android.accessibilityservice" android:resource="@xml/accessibility_service_config"/>
</service>
</application>
</manifest>
EOF

cat > app/src/main/java/com/vt100/ime/VT100ImeService.java <<'EOF'
package com.vt100.ime;
import android.inputmethodservice.InputMethodService;
import android.view.View;
import android.view.inputmethod.InputConnection;
public class VT100ImeService extends InputMethodService {
    private VT100KeyboardView view;
    @Override public View onCreateInputView(){ view=new VT100KeyboardView(this); return view; }
    public InputConnection connection(){ return getCurrentInputConnection(); }
    @Override public void onStartInputView(android.view.inputmethod.EditorInfo info, boolean restarting){
        super.onStartInputView(info,restarting);
        if(view!=null)view.resetTransientState();
    }
}
EOF

cat > app/src/main/java/com/vt100/ime/VT100AccessibilityService.java <<'EOF'
package com.vt100.ime;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;
public class VT100AccessibilityService extends AccessibilityService {
    private static VT100AccessibilityService instance;
    @Override public void onServiceConnected(){instance=this;}
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){instance=null;super.onDestroy();}
    public static void tap(float x,float y){
        if(instance==null)return;
        Path p=new Path();p.moveTo(x,y);
        instance.dispatchGesture(new GestureDescription.Builder()
          .addStroke(new GestureDescription.StrokeDescription(p,0,50)).build(),null,null);
    }
}
EOF

cat > app/src/main/java/com/vt100/ime/SettingsActivity.java <<'EOF'
package com.vt100.ime;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;
public class SettingsActivity extends Activity {
 @Override protected void onCreate(Bundle b){
  super.onCreate(b);
  LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(30,30,30,20);
  TextView t=new TextView(this);t.setText("VT-100 PC Touch Keyboard v0.2");t.setTextSize(22);
  TextView i=new TextView(this);i.setText("Enable the keyboard, choose it from the keyboard picker, then optionally enable VT-100 Touchpad under Accessibility.");i.setTextSize(16);i.setPadding(0,25,0,25);
  Button a=new Button(this);a.setText("Keyboard settings");a.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
  Button p=new Button(this);p.setText("Choose keyboard");p.setOnClickListener(v->((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker());
  Button x=new Button(this);x.setText("Accessibility settings");x.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
  r.addView(t);r.addView(i,new LinearLayout.LayoutParams(-1,0,1));r.addView(a);r.addView(p);r.addView(x);setContentView(r);
 }
}
EOF

cat > app/src/main/java/com/vt100/ime/VT100KeyboardView.java <<'EOF'
package com.vt100.ime;
import android.graphics.*;
import android.inputmethodservice.InputMethodService;
import android.os.SystemClock;
import android.view.*;
import android.view.inputmethod.InputConnection;
import java.util.*;

public class VT100KeyboardView extends View {
 private final VT100ImeService service; private final Paint p=new Paint(1); private final ArrayList<Key> keys=new ArrayList<>();
 private boolean shift,ctrl,alt,caps,fn,pad; private float sx,sy,lastX,lastY; private long down;
 static final int TEXT=0,SPECIAL=1,MOD=2,PAD=3,ACTION=4;
 static class Key{RectF r;String a,b;int t;Key(float x,float y,float w,float h,String a,String b,int t){r=new RectF(x,y,x+w,y+h);this.a=a;this.b=b;this.t=t;}}
 public VT100KeyboardView(VT100ImeService s){super(s);service=s;setBackgroundColor(Color.rgb(15,15,21));}
 float X(){return getWidth()/1000f;} float Y(){return getHeight()/540f;}
 void add(float x,float y,float w,float h,String a,String b,int t){keys.add(new Key(x,y,w,h,a,b,t));}
 @Override protected void onDraw(Canvas c){
  c.save();c.scale(X(),Y());p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(15,15,21));c.drawRect(0,0,1000,540,p);keys.clear();layout();
  for(Key k:keys){boolean on=k.t==MOD&&((k.a.equals("Shift")&&shift)||(k.a.equals("Ctrl")&&ctrl)||(k.a.equals("Alt")&&alt)||(k.a.equals("Caps")&&caps)||(k.a.equals("Fn")&&fn));p.setColor(on?Color.rgb(122,162,247):k.t==PAD?Color.rgb(27,31,43):Color.rgb(35,36,49));p.setStyle(Paint.Style.FILL);c.drawRoundRect(k.r,7,7,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.rgb(72,78,98));c.drawRoundRect(k.r,7,7,p);p.setStyle(Paint.Style.FILL);p.setColor(on?Color.BLACK:Color.rgb(215,220,238));String s=k.t==TEXT&&shift&&!k.b.isEmpty()?k.b:k.a;p.setTextAlign(Paint.Align.CENTER);p.setTextSize(s.length()>7?13:18);Paint.FontMetrics f=p.getFontMetrics();c.drawText(s,k.r.centerX(),k.r.centerY()-(f.ascent+f.descent)/2,p);if(k.t==PAD){p.setTextSize(14);p.setColor(Color.rgb(122,162,247));c.drawText("TOUCHPAD",k.r.centerX(),k.r.centerY()-15,p);p.setTextSize(11);c.drawText("TAP • SWIPE • DRAG",k.r.centerX(),k.r.centerY()+15,p);c.drawText("SHIFT+SWIPE = SELECT",k.r.centerX(),k.r.centerY()+32,p);}}
  c.restore();
 }
 void layout(){
  add(5,5,50,45,"Esc","",SPECIAL);float x=60;for(int i=1;i<=12;i++){add(x,5,62,45,"F"+i,"",SPECIAL);x+=65;}add(850,5,70,45,"PrtSc","",SPECIAL);add(925,5,70,45,"Pause","",SPECIAL);
  String[] n={"`","1","2","3","4","5","6","7","8","9","0","-","="},s={"~","!","@","#","$","%","^","&","*","(",")","_","+"};x=5;add(x,55,48,46,n[0],s[0],TEXT);x+=53;for(int i=1;i<n.length;i++){add(x,55,47,46,n[i],s[i],TEXT);x+=52;}add(690,55,305,46,"Backspace","",SPECIAL);
  add(5,106,70,47,"Tab","",SPECIAL);x=80;String[] q={"Q","W","E","R","T","Y","U","I","O","P","[","]","\\"},qs={"","","","","","","","","","","{","}","|"};for(int i=0;i<q.length;i++){add(x,106,62,47,q[i],qs[i],TEXT);x+=66;}
  add(5,158,82,47,"Caps","",MOD);x=92;String[] a={"A","S","D","F","G","H","J","K","L",";","'"},as={"","","","","","","","","",":","\""};for(int i=0;i<a.length;i++){add(x,158,62,47,a[i],as[i],TEXT);x+=66;}add(825,158,170,47,"Enter","",SPECIAL);
  add(5,210,105,47,"Shift","",MOD);x=115;String[] z={"Z","X","C","V","B","N","M",",",".","/"},zs={"","","","","","","","<",">","?"};for(int i=0;i<z.length;i++){add(x,210,62,47,z[i],zs[i],TEXT);x+=66;}add(780,210,105,47,"Shift","",MOD);add(890,210,105,47,"Delete","",SPECIAL);
  add(5,262,78,50,"Ctrl","",MOD);add(88,262,78,50,"Alt","",MOD);add(171,262,78,50,"Fn","",MOD);add(254,262,390,155,"TOUCHPAD","",PAD);add(649,262,92,72,"L-CLICK","",ACTION);add(746,262,92,72,"R-CLICK","",ACTION);add(843,262,72,72,"Home","",SPECIAL);add(920,262,75,72,"End","",SPECIAL);
  add(843,340,72,44,"↑","",SPECIAL);add(766,340,72,44,"←","",SPECIAL);add(843,388,72,44,"↓","",SPECIAL);add(920,340,75,44,"→","",SPECIAL);add(649,340,92,44,"PgUp","",SPECIAL);add(649,388,92,44,"PgDn","",SPECIAL);
  add(5,440,110,45,"Clipboard","",ACTION);add(120,440,100,45,"Emoji","",ACTION);add(225,440,105,45,"Language","",ACTION);add(335,440,405,45,"SPACE","",SPECIAL);add(745,440,75,45,"Esc","",SPECIAL);add(825,440,75,45,"Tab","",SPECIAL);add(905,440,90,45,"Enter","",SPECIAL);
  add(5,490,105,42,"Ctrl+A","",ACTION);add(115,490,105,42,"Ctrl+C","",ACTION);add(225,490,105,42,"Ctrl+V","",ACTION);add(335,490,105,42,"Ctrl+X","",ACTION);add(445,490,105,42,"Ctrl+Z","",ACTION);add(555,490,105,42,"Ctrl+Y","",ACTION);add(665,490,105,42,"Ctrl+F","",ACTION);add(775,490,105,42,"Ctrl+S","",ACTION);add(885,490,110,42,"Select All","",ACTION);
 }
 Key hit(float x,float y){for(Key k:keys)if(k.r.contains(x,y))return k;return null;}
 @Override public boolean onTouchEvent(MotionEvent e){float x=e.getX()/X(),y=e.getY()/Y();if(e.getAction()==0){lastX=x;lastY=y;down=SystemClock.uptimeMillis();Key k=hit(x,y);pad=k!=null&&k.t==PAD;performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);return true;}if(e.getAction()==2&&pad){float dx=x-lastX,dy=y-lastY;if(Math.abs(dx)>40||Math.abs(dy)>40){nav(Math.abs(dx)>=Math.abs(dy)?(dx>0?22:21):(dy>0?20:19));lastX=x;lastY=y;}return true;}if(e.getAction()==1){Key k=hit(x,y);if(pad){if(Math.abs(x-lastX)<25&&Math.abs(y-lastY)<25&&SystemClock.uptimeMillis()-down<450)commit(" ");return true;}if(k!=null)press(k);return true;}return true;}
 void press(Key k){String n=k.a;if(k.t==MOD){if(n.equals("Shift"))shift=!shift;else if(n.equals("Ctrl"))ctrl=!ctrl;else if(n.equals("Alt"))alt=!alt;else if(n.equals("Caps"))caps=!caps;else fn=!fn;invalidate();return;}if(k.t==ACTION){action(n);return;}if(k.t==TEXT){if(ctrl||alt){int c=letter(n);if(c>=0)send(c,meta());ctrl=alt=shift=false;}else if(shift){int c=letter(n);if(c>=0)send(c,1);else commit(k.b.isEmpty()?n:k.b);shift=false;}else{String o=n;if(caps&&o.length()==1&&Character.isLetter(o.charAt(0)))o=o.toUpperCase(Locale.US);commit(o);}invalidate();return;}if(n.equals("SPACE")){commit(" ");return;}int c=code(n);if(c>=0){send(c,meta());if(n.equals("←")||n.equals("→")||n.equals("↑")||n.equals("↓")||n.equals("Home")||n.equals("End")||n.equals("Delete")||n.equals("PgUp")||n.equals("PgDn"))shift=ctrl=alt=false;invalidate();}}
 void action(String n){if(n.equals("L-CLICK")){VT100AccessibilityService.tap(500,500);return;}if(n.equals("R-CLICK"))return;if(n.equals("Language")){((android.view.inputmethod.InputMethodManager)service.getSystemService(android.content.Context.INPUT_METHOD_SERVICE)).showInputMethodPicker();return;}if(n.equals("Emoji")){commit("😀");return;}if(n.equals("Clipboard")){commit("");return;}if(n.equals("Select All")){send(letter("A"),2);return;}if(n.startsWith("Ctrl+")){int c=letter(n.substring(5));if(c>=0)send(c,2);}}
 int meta(){return (shift?1:0)|(ctrl?4096:0)|(alt?2:0);}void nav(int c){send(c,meta());}void commit(String s){InputConnection i=service.connection();if(i!=null)i.commitText(s,1);}void send(int c,int m){InputConnection i=service.connection();if(i==null)return;long t=SystemClock.uptimeMillis();i.sendKeyEvent(new KeyEvent(t,t,0,c,0,m));i.sendKeyEvent(new KeyEvent(t,t,1,c,0,m));}
 int letter(String s){if(s.length()!=1)return -1;char c=Character.toUpperCase(s.charAt(0));return c>='A'&&c<='Z'?KeyEvent.KEYCODE_A+c-'A':-1;}
 int code(String s){switch(s){case"Esc":return 111;case"Tab":return 61;case"Enter":return 66;case"Backspace":return 67;case"Delete":return 112;case"Home":return 122;case"End":return 123;case"←":return 21;case"→":return 22;case"↑":return 19;case"↓":return 20;case"PgUp":return 92;case"PgDn":return 93;case"F1":return 131;case"F2":return 132;case"F3":return 133;case"F4":return 134;case"F5":return 135;case"F6":return 136;case"F7":return 137;case"F8":return 138;case"F9":return 139;case"F10":return 140;case"F11":return 141;case"F12":return 142;case"PrtSc":return 120;case"Pause":return 121;default:return -1;}}
 public void resetTransientState(){shift=ctrl=alt=fn=false;invalidate();}
}
EOF

cat > .github/workflows/build.yml <<'EOF'
name: Build VT-100 IME
on: {workflow_dispatch: null, push: {branches: ["main"]}}
jobs:
 build:
  runs-on: ubuntu-latest
  steps:
   - uses: actions/checkout@v4
   - uses: actions/setup-java@v5
     with: {distribution: temurin, java-version: "17"}
   - uses: gradle/actions/setup-gradle@v6
     with: {gradle-version: "8.7"}
   - run: gradle --no-daemon assembleDebug
   - uses: actions/upload-artifact@v4
     with:
      name: VT100-IME-v0.2-debug
      path: app/build/outputs/apk/debug/app-debug.apk
EOF

echo "VT-100 v0.2 files created."
echo "Now run: gradle assembleDebug"
